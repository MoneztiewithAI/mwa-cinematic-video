# Final polish and review

Run this before every delivery: on stills taken just before and after each cut and each big move (`node render.js --stills ...`), and on the 1-fps contact sheets of the full render. Fix, rebuild and re-render until it all passes. Add new lessons at the bottom.

## Every paused frame is a production still

- Composition holds up on its own: clear subject, foreground, middle ground and background, nothing awkwardly cropped at the frame edge.
- Lines are tapered and varied. No uniform vector strokes anywhere.
- Shading is cel: designed shadow shapes, restrained and never black. No glossy highlights, no airbrushed gradients.
- Backgrounds read as painted: brush marks, paper texture, weathering. No stamped, repeated assets.
- Nothing flickers between frames: textures, grain and line wobble are fixed per drawing.
- The light comes from the same side for everything in a scene.

## Continuity across transitions

- Characters keep the same proportions, colors and costume details from shot to shot and in every pose.
- Each shot follows from the one before: same things in the same places, same screen direction, the action continues across the cut.
- Every pickup, hand-off and change of state happens on screen.
- The camera never shows the edge of a painted plate (make plates bigger than the frame when the camera moves).

## Acting and motion

- Key poses read in silhouette and are held long enough to register.
- Anticipation before big moves, weight on landings, follow-through in hair, cloth and tails. Nothing floats on one smooth ease.
- Arms and legs are the right length and bend the right way. Hands and feet touch what they use; feet are on the ground (no floating or sinking).
- Characters never overlap or pass through each other; nothing clips through walls, trees or props.
- Secondary motion agrees with the wind and the action.
- Faces read: eyes visible in the shots that matter, expressions match the beat.

## Story

- There's a clear progression from the first shot to the last, and the emotional turn lands. It isn't an aimless loop.
- Everything on screen belongs to this premise. Nothing was invented beyond what was asked for without saying so.

## Sound

- Sound lands on its action: steps match feet, the thud matches the landing, the gust matches the grass.
- The music supports the emotional turn and doesn't fight the effects.

## Production lessons learned

- **Architectural and landmark continuity across cuts**: When cutting between wide, medium, and close-up shots (or wide tracking pans), preserve every nearby structure, wall edge, pillar, lamp mount, and landmark tree in its exact spatial position. Never let a shelter wall, roof support, or background tree vanish or appear between cuts, and never leave hanging lamps floating without visible eaves or posts.
- **Physical occlusion for dynamic lighting and depth**: Clip moving light sweeps (train window shafts, headlights, sunbeams) to open bays or windows so light never shines through opaque foreground walls. Use soft gradients rather than hard-edged rectangles for shadow veils, align `rayFan` centers to the actual sun/horizon glow, and enrich wide perspective shots with receding details (sleepers, utility poles, sagging wires, weathered seams) so large ground planes never read as empty.
- **Seamless limb-to-torso blending (no puppet joints)**: Avoid drawing closed dark ink rings at the top root of near-side limbs. Use continuous tapered leg silhouettes blended seamlessly into the torso shoulder/haunch (inking only the outer/lower 75% of near limbs), and flex the spine visibly during runs and leaps.
- **Weight-appropriate foley (avoid accidental drumbeats)**: Never use low-frequency stone or wood footsteps (`step('stone')`) or heavy percussive bass pulses for lightweight subjects (cats, birds, small animals) because the ~95 Hz thump reads like a distracting drumbeat. Use whisper-light high-band noise taps for padded paws and flowing, soft-attack harp/strings for gentle motion.
