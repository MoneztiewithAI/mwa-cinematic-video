// Render the built HTML to MP4 with parallel headless Chromium workers (zero external deps via CDP pipe),
// then add sound and review sheets.
//   node render.js                         full render -> build/<slug>.mp4 (+ build/review/contact-*.jpg)
//   node render.js --stills 1,4.5,9        quick PNG stills -> build/stills/ + build/stills/sheet.jpg
//   node render.js --design                design sheet of the cast / key elements -> build/design/design-sheet*.png
//   options: --html build/x.html --out build/x.mp4 --workers 4 --scale 0.5 (draft) | 2 (4K) --from 3 --to 8 --no-audio
import { spawn, execFileSync } from 'child_process';
import { readFileSync, readdirSync, mkdirSync, writeFileSync, existsSync, rmSync } from 'fs';
import { resolve, join } from 'path';
import os from 'os';

const A = process.argv.slice(2);
const arg = (k, d) => { const i = A.indexOf('--' + k); return i < 0 ? d : A[i + 1]; };
const flag = k => A.includes('--' + k);

const beats = JSON.parse(readFileSync('src/beats.json', 'utf8'));
const slug = (beats.title || 'video').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
const htmlPath = resolve(arg('html', `build/${slug}.html`));
const scale = +arg('scale', 1);
const workers = +arg('workers', Math.max(1, Math.min(4, os.cpus().length - 1)));
const extraArgs = process.env.CINEMATIC_CHROME_ARGS ? process.env.CINEMATIC_CHROME_ARGS.split(' ').filter(Boolean) : [];

// Inject render mode + scale flags directly into the HTML so Page.setDocumentContent works
// with zero network/file:// navigation (compatible with managed Chromium URL blocklists).
const rawHtml = readFileSync(htmlPath, 'utf8');
const inject = `<script>window.__RENDER_MODE=true;window.__RENDER_SCALE=${scale};</script>`;
const htmlContent = rawHtml.includes('<head>') ? rawHtml.replace('<head>', `<head>${inject}`) : inject + rawHtml;

function findChrome() {
  const candidates = [
    process.env.CINEMATIC_CHROME_BIN,
    '/usr/bin/chromium',
    '/usr/bin/chromium-browser',
    '/usr/bin/google-chrome',
    '/usr/bin/google-chrome-stable',
    '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  ].filter(Boolean);
  for (const bin of candidates) {
    if (existsSync(bin)) return bin;
  }
  throw new Error('No Chromium/Chrome binary found. Set CINEMATIC_CHROME_BIN to your browser path.');
}

const CHROME_BIN = findChrome();

async function openPage() {
  const proc = spawn(CHROME_BIN, [
    '--headless=new',
    '--no-sandbox',
    '--disable-dev-shm-usage',
    '--disable-gpu',
    '--hide-scrollbars',
    '--mute-audio',
    '--remote-debugging-pipe',
    ...extraArgs,
    'about:blank',
  ], { stdio: ['ignore', 'ignore', 'pipe', 'pipe', 'pipe'] });

  let nextId = 1;
  const pending = new Map();
  let acc = Buffer.alloc(0);

  proc.stdio[4].on('data', chunk => {
    acc = Buffer.concat([acc, chunk]);
    let idx;
    while ((idx = acc.indexOf(0)) !== -1) {
      const raw = acc.subarray(0, idx).toString('utf8');
      acc = acc.subarray(idx + 1);
      if (!raw) continue;
      let msg;
      try { msg = JSON.parse(raw); } catch { continue; }
      if (msg.id && pending.has(msg.id)) {
        const { resolve: res, reject: rej } = pending.get(msg.id);
        pending.delete(msg.id);
        if (msg.error) rej(new Error(msg.error.message || JSON.stringify(msg.error)));
        else res(msg.result);
      } else if (msg.method === 'Runtime.exceptionThrown') {
        const ex = msg.params?.exceptionDetails;
        console.log('PAGE ERROR', ex?.exception?.description || ex?.text || 'unknown');
      } else if (msg.method === 'Runtime.consoleAPICalled') {
        const t = msg.params?.type;
        if (t === 'error' || t === 'warning') {
          const text = (msg.params.args || []).map(a => a.value ?? a.description ?? '').join(' ');
          console.log('console:', text);
        }
      }
    }
  });

  proc.on('exit', () => {
    for (const { reject: rej } of pending.values()) rej(new Error('Chromium exited unexpectedly'));
    pending.clear();
  });

  const send = (method, params = {}, sessionId = undefined) => new Promise((res, rej) => {
    const id = nextId++;
    pending.set(id, { resolve: res, reject: rej });
    const payload = sessionId ? { id, method, params, sessionId } : { id, method, params };
    proc.stdio[3].write(JSON.stringify(payload) + '\0');
  });

  const { targetId } = await send('Target.createTarget', { url: 'about:blank' });
  const { sessionId } = await send('Target.attachToTarget', { targetId, flatten: true });
  await send('Page.enable', {}, sessionId);
  await send('Runtime.enable', {}, sessionId);
  await send('Emulation.setDeviceMetricsOverride', {
    width: 1280, height: 720, deviceScaleFactor: 1, mobile: false,
  }, sessionId);

  const evalJS = async (expression) => {
    const r = await send('Runtime.evaluate', {
      expression, returnByValue: true, awaitPromise: true,
    }, sessionId);
    if (r.exceptionDetails) {
      throw new Error(r.exceptionDetails.exception?.description || r.exceptionDetails.text || 'JS eval error');
    }
    return r.result ? r.result.value : undefined;
  };

  const { frameTree } = await send('Page.getFrameTree', {}, sessionId);
  await send('Page.setDocumentContent', { frameId: frameTree.frame.id, html: htmlContent }, sessionId);

  const deadline = Date.now() + 120000;
  while (Date.now() < deadline) {
    const ready = await evalJS('window.__ready === true').catch(() => false);
    if (ready) break;
    await new Promise(r => setTimeout(r, 50));
  }
  const ok = await evalJS('window.__ready === true');
  if (!ok) {
    proc.kill('SIGKILL');
    throw new Error('Timed out waiting for window.__ready');
  }

  const close = async () => {
    try { await send('Browser.close'); } catch {}
    setTimeout(() => { try { proc.kill('SIGKILL'); } catch {} }, 500).unref();
  };

  return { evalJS, close };
}

const grab = (page, t, type = 'image/jpeg') =>
  page.evalJS(`(() => { renderAt(${t}); return document.getElementById('c').toDataURL(${JSON.stringify(type)}, 0.94); })()`)
    .then(d => Buffer.from(d.slice(d.indexOf(',') + 1), 'base64'));

if (A.includes('--design')) {
  const dir = 'build/design'; mkdirSync(dir, { recursive: true });
  const page = await openPage();
  const hasDesign = await page.evalJS('Boolean(window.renderDesign)');
  if (!hasDesign) {
    await page.close();
    console.log('no design sheet: define window.renderDesign in src/90_design.js');
    process.exit(1);
  }
  const d = await page.evalJS('window.renderDesign()');
  const file = join(dir, `design-sheet${existsSync(join(dir, 'design-sheet.png')) ? '-' + Date.now().toString(36) : ''}.png`);
  writeFileSync(file, Buffer.from(d.slice(d.indexOf(',') + 1), 'base64'));
  await page.close();
  console.log(`design sheet -> ${file}`);
  process.exit(0);
}

if (A.includes('--stills')) {
  const times = arg('stills', '0').split(',').map(Number);
  const dir = 'build/stills'; rmSync(dir, { recursive: true, force: true }); mkdirSync(dir, { recursive: true });
  const page = await openPage();
  for (const [i, t] of times.entries()) {
    writeFileSync(join(dir, `s${String(i).padStart(2, '0')}_${t.toFixed(2)}s.png`), await grab(page, t, 'image/png'));
  }
  await page.close();
  const cols = Math.min(4, times.length);
  execFileSync('ffmpeg', ['-y', '-loglevel', 'error', '-pattern_type', 'glob', '-i', `${dir}/s*.png`, '-vf', `scale=640:-1,tile=${cols}x${Math.ceil(times.length / cols)}:padding=6:color=white`, '-frames:v', '1', `${dir}/sheet.jpg`]);
  console.log(`stills -> ${dir}/ (sheet.jpg is ${cols} across, in the order given)`);
  process.exit(0);
}

const probe = await openPage();
const V = await probe.evalJS('window.VIDEO');
await probe.close();

const fps = V.fps, f0 = Math.round(+arg('from', 0) * fps), f1 = Math.round(+arg('to', V.duration) * fps);
const out = resolve(arg('out', `build/${slug}${scale !== 1 ? `-x${scale}` : ''}.mp4`));
const tmp = 'build/segments'; rmSync(tmp, { recursive: true, force: true }); mkdirSync(tmp, { recursive: true });
console.log(`rendering ${f1 - f0} frames (${((f1 - f0) / fps).toFixed(1)} s) at ${V.width * scale}x${V.height * scale}, ${fps} fps, ${workers} workers`);
const T0 = Date.now(); let done = 0;

async function worker(w, a, z) {
  const segFile = join(tmp, `seg${w}.mp4`);
  const ff = spawn('ffmpeg', ['-y', '-loglevel', 'error', '-f', 'image2pipe', '-framerate', String(fps), '-c:v', 'mjpeg', '-i', '-',
    '-c:v', 'libx264', '-preset', 'medium', '-crf', '19', '-pix_fmt', 'yuv420p', '-r', String(fps), segFile]);
  ff.stderr.on('data', d => process.stderr.write(d));
  const page = await openPage();
  for (let f = a; f < z; f++) {
    const buf = await grab(page, f / fps);
    if (!ff.stdin.write(buf)) await new Promise(r => ff.stdin.once('drain', r));
    if (++done % (fps * 5) === 0) {
      const s = (Date.now() - T0) / 1000;
      console.log(`  ${done}/${f1 - f0} frames, ${s.toFixed(0)} s, ~${(s / done * (f1 - f0 - done)).toFixed(0)} s left`);
    }
  }
  ff.stdin.end();
  await new Promise(r => ff.on('close', r));
  await page.close();
  return segFile;
}

const n = f1 - f0, per = Math.ceil(n / workers), jobs = [];
for (let w = 0; w < workers; w++) {
  const a = f0 + w * per, z = Math.min(f1, a + per);
  if (a < z) jobs.push(worker(w, a, z));
}
const segs = await Promise.all(jobs);
writeFileSync(join(tmp, 'list.txt'), segs.map(s => `file '${resolve(s)}'`).join('\n'));
const silent = join(tmp, 'video.mp4');
execFileSync('ffmpeg', ['-y', '-loglevel', 'error', '-f', 'concat', '-safe', '0', '-i', join(tmp, 'list.txt'), '-c', 'copy', silent]);

if (existsSync('build/audio.wav') && !flag('no-audio')) {
  const ss = (f0 / fps).toFixed(3), dur = (n / fps).toFixed(3);
  execFileSync('ffmpeg', ['-y', '-loglevel', 'error', '-i', silent, '-ss', ss, '-t', dur, '-i', 'build/audio.wav',
    '-af', 'loudnorm=I=-16:TP=-1.5:LRA=11', '-ar', '48000', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-shortest', '-movflags', '+faststart', out]);
} else {
  execFileSync('ffmpeg', ['-y', '-loglevel', 'error', '-i', silent, '-c', 'copy', '-movflags', '+faststart', out]);
}
rmSync(tmp, { recursive: true, force: true });

// review sheets: one tile per second, 6 across, 5 rows = 30 s per sheet
const rev = 'build/review'; rmSync(rev, { recursive: true, force: true }); mkdirSync(rev, { recursive: true });
const rows = Math.max(1, Math.min(5, Math.ceil(n / fps / 6)));
execFileSync('ffmpeg', ['-y', '-loglevel', 'error', '-i', out, '-vf', `fps=1,scale=480:-1,tile=6x${rows}:padding=4:color=white`, `${rev}/contact-%02d.jpg`]);
console.log(`done in ${((Date.now() - T0) / 1000).toFixed(0)} s -> ${out}`);
console.log(`review sheets -> ${rev}/ (${readdirSync(rev).length} sheet(s), tile n = second n of the clip, left to right, top to bottom)`);
process.exit(0);
