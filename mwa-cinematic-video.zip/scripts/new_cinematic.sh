#!/bin/bash
# Start a cinematic animation project from the skill's template and check offline local tools.
# usage: new_cinematic.sh <project-folder>
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
P="$1"
[ -z "$P" ] && { echo "usage: new_cinematic.sh <project-folder>"; exit 1; }
if [ -e "$P/src/beats.json" ]; then echo "$P already has a project; not overwriting"; exit 1; fi
mkdir -p "$P"
cp -R "$HERE/../template/." "$P/"
cd "$P"

missing=()
command -v node >/dev/null || missing+=("node")
command -v ffmpeg >/dev/null || missing+=("ffmpeg")
command -v python3 >/dev/null || missing+=("python3")
if ! command -v chromium >/dev/null && ! command -v chromium-browser >/dev/null && ! command -v google-chrome >/dev/null && [ -z "$CINEMATIC_CHROME_BIN" ]; then
  missing+=("chromium")
fi
[ ${#missing[@]} -gt 0 ] && { echo "missing: ${missing[*]}"; exit 1; }

if ! python3 -c "import numpy, scipy" 2>/dev/null; then
  echo "missing python packages: numpy and scipy"
  exit 1
fi

echo "ready: $P  (edit src/beats.json, src/10_example.js, audio/audio.py)"
