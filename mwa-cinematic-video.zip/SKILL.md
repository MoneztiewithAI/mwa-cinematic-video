---
name: mwa-cinematic-video
description: Make a short cinematic animated sequence in the style of classic Japanese feature animation (such as Studio Ghibli), with tapered ink lines, cel shading, and painted watercolor or gouache backgrounds, delivered as one self-contained HTML file with sound plus an MP4 rendered from the same code. Use whenever the user asks for a "cinematic animation", "anime-style" or "Ghibli-style" animation, a hand-drawn Japanese-style film moment, or in Chinese asks for 吉卜力风格动画, 日系手绘动画短片, 电影感动画, 手绘动画视频, or asks to redo or extend one of these. Before building, asks for the subject, setting, and action (never invents the premise), plus the length and whether to plan together first; defaults are 30 seconds and straight to work.
---

# mwa-cinematic-video

Makes a short animated sequence styled after classic Japanese feature animation (for example Studio Ghibli), delivered as one self-contained HTML file that plays in a browser with sound, plus a 1080p 24fps MP4 rendered frame by frame from the same code. It should feel like a genuine film moment with emotional weight, not a web graphics demo.

This skill runs fully offline in the VM sandbox using pre-installed Node.js, FFmpeg, Python (`numpy` + `scipy`), and headless Chromium via zero-dependency Chrome DevTools Protocol (no Playwright or internet required).

## Bundled Resources

Before starting a project, fetch the required bundled files from this skill using `get_skill_resources`:

- References: `references/look.md`, `references/craft.md`, `references/review.md`
- Setup script: `scripts/new_cinematic.sh`
- Template runtime and build pipeline: `template/package.json`, `template/build.js`, `template/render.js`
- Template 2D hand-drawn render kit: `template/src/beats.json`, `template/src/00_core.js`, `template/src/01_ink.js`, `template/src/02_paint.js`, `template/src/03_shapes.js`, `template/src/04_kit.js`, `template/src/10_example.js`, `template/src/90_design.js`, `template/src/99_main.js`
- Template procedural audio synth: `template/audio/audiolib.py`, `template/audio/audio.py`

The template holds a working 13-second example ("The Straw Hat": a straw hat on a fence post is carried off by the wind).

## 1. Clarify before building

Never invent the premise. Check the request for these items:

- **Subject**: who or what the scene is about.
- **Setting**: where and when it happens (place, time of day, weather, season).
- **Action**: what happens in the scene, from start to end.
- **Length**: how long it should be.
- **Plan together or just get to work**: plan the scene together first, or go straight to making it?

If the subject, setting, or action is missing or vague, ask for it before writing any code. Ask only for what was not given, in one short message, and state the defaults for the rest: 30 seconds for length, and getting straight to work if there is no preference. Do not fill gaps in the premise yourself, and do not add requirements nobody asked for. When you deliver, write one line naming any choice you made on the user's behalf (a title, a character's colors, an extra beat), so it is easy to change.

**Fixed (do not ask):** the look in section 2, 16:9 at 1920x1080, 24 fps, music and sound effects on.

## 2. Core aesthetic and execution

Read `references/look.md` before designing anything. In short:

- **Output:** one standalone HTML file plus an MP4 rendered from the same code. The template uses a plain 2D canvas with zero external libraries. All designs must be completely original. Never copy characters, creatures, places, or shots from existing films.
- **Art direction:** organic, tapered ink lines; classic cel-shaded color with restrained shadows (one shadow tone, sometimes a rim of light); textured watercolor- or gouache-style painted backgrounds. Add subtle weathering and natural irregularities (chipped paint, moss, worn paths, uneven edges) so the world feels lived-in.
- **Animation and directing:** strong key poses, variable timing, anticipation, weight, and natural secondary motion (wind in hair, drifting leaves, cloth, grass) instead of rigid, mechanical tweening. Frame each shot cinematically, with a clear narrative progression from the first shot to the last rather than an aimless loop.

## 3. What to avoid

Eliminate the telltale signs of cheap digital graphics:

- uniform vector strokes (every line the same weight)
- glossy 3D shading, specular highlights, plastic surfaces
- repetitive procedural assets (the same tree, house, or cloud stamped over and over)
- floaty easing curves (everything sliding on the same smooth in-out)
- flickering details (noise, grain, or texture that changes every frame)
- soft airbrushed gradients (use painted strokes instead)

## 4. Plan the scene

- Find the emotional turn: what the character wants or feels at the start, and how that has changed by the end. Every shot should move toward it.
- Write a short shot list: one line per shot with rough times, the framing (wide, medium, close), the camera move, and what the shot shows. Vary the framing: an establishing wide, mediums for action, a close-up for the emotional beat, a release shot to end.

**If planning together was chosen**, get sign-off before building the scenes:

1. Share the shot list.
2. Initialize the project (section 5), draw just the main characters and key objects, build (`node build.js`), and render a design sheet with `node render.js --design` (key poses and expressions for each, with a name and a one-line note).
3. Inspect `build/design/design-sheet.png` visually using `view_file`, then copy it to the output folder and show it to the user alongside the shot list. Wait for approval. Revise and share a new sheet until approved, then build the shots.

**If getting straight to work was chosen** (or nothing was chosen), share the shot list for reference and keep building without waiting.

## 5. Start the project

- Create a working project directory `P` in the sandbox workspace (e.g. `<workspace>/<slug>-cinematic/`).
- Fetch the template files via `get_skill_resources` and place them into `P/` preserving the directory layout (`src/`, `audio/`, `build.js`, `render.js`, `package.json`), or run `bash scripts/new_cinematic.sh "$P"` if unpacked locally.
- Verify local tools are available (offline, no `npm install` or `pip install`): `node`, `ffmpeg`, `chromium` (or `CINEMATIC_CHROME_BIN`), and `python3 -c "import numpy, scipy"`.
- Layout: `src/beats.json` (title, length, cue times), `src/00_core.js` (math, seeded noise, color, geometry, shot list), `src/01_ink.js` (tapered ink lines and cels), `src/02_paint.js` (brush dabs, painted regions and skies, paper), `src/03_shapes.js` (cel shapes, limbs, ribbons, cloud masses), `src/04_kit.js` (foliage, trees, clouds, grass, haze, camera, plates), `src/10_example.js` (example scene), `src/90_design.js` (design sheet), `src/99_main.js` (timeline, transitions, film finish, player), `audio/audio.py` + `audio/audiolib.py` (sound), `build.js`, `render.js`, and `build/` for outputs.
- Replace `src/10_example.js` and `src/90_design.js` entirely. Put characters and props in their own numbered files (`05_hero.js`, `06_props.js`, ...) and shots in `10_...`, `20_...` files. `build.js` joins `src/*.js` in filename order.

## 6. Build

Read `references/craft.md` before writing scene code.

1. **Beats.** Write `src/beats.json`: `title`, `duration`, `fps`, and named `cues` for every moment that needs a sound or a cut. Picture and sound both read these times, so change timing here only.
2. **Characters and props.** Design each one original: a clear silhouette, a small limited palette, tapered ink outline, one shadow shape, and an optional rim light. Draw each as a function of its pose so every shot and the design sheet use the same drawing.
3. **Backgrounds.** Paint each shot's background once into a plate in its `prep` (sky in brush strokes, painted regions, foliage, weathering, paper texture), then draw the moving parts on top every frame. Vary every repeated element (size, shape, color, spacing).
4. **Acting.** Animate characters on twos (`on2(t)`, 12 drawings a second) with held key poses and short, decisive moves between them (`kf` with `E.out3`, `E.in2`, not one ease everywhere). Show anticipation before big moves, weight on landings, and overlap and follow-through in hair, cloth, and tails. Cameras move on ones so pans stay smooth.
5. **Shots.** `shot(name, t0, t1, prep, draw, { in })` for each shot, with an optional `dissolve` or `dip` transition. Shots must cover the whole duration with no gaps.
6. **Every frame depends only on `t`.** No clocks, no `Math.random`, no state carried from the last frame. Use `RNG(seed)`, `hash`, and `n1`/`n2` for anything organic.
7. **Quick checks:** run `node build.js`, then `node render.js --stills 1,4.5,9` (pick one time inside each shot and on each side of every cut). Inspect `build/stills/sheet.jpg` with `view_file` and fix visual problems before running the full render.

## 7. Sound

Edit `audio/audio.py`: a score that carries the emotion (often a small melody on piano, strings, woodwinds, or harp, with room to breathe), ambience that places the scene (wind, rain, birds, sea), and sound effects on the cues from `beats.json`. `audiolib.py` has instruments, effects, and ambience beds; add new sounds there when needed. Run `python3 audio/audio.py build/audio.wav`. Add a voiceover only if one is asked for.

## 8. Render and final polish

1. Run `node build.js` to write `build/<slug>.html` with the AAC sound embedded inside.
2. Run `node render.js` to render with parallel headless Chromium workers via CDP pipe, mix the sound at -16 LUFS, and write `build/<slug>.mp4` plus `build/review/contact-*.jpg` (one tile per second). Use `--scale 0.5` for a fast draft, or `--from`/`--to` for a section. Heavy painted plates make the first frame of each shot slow; after that it is fast.
3. **Final visual polish:** inspect individual frames across every key transition (`node render.js --stills` just before and after each cut and big move) AND inspect the contact sheets (`build/review/contact-*.jpg`) with `view_file`, checking against `references/review.md`: consistent character proportions, strong composition, visual cohesion. Every paused frame should hold up as a finished production still. Fix, rebuild, and re-render until it passes.

## 9. Deliver

- Copy the final `build/<slug>.html` and `build/<slug>.mp4` into the workspace deliverable output folder (`<workspace>/artifacts/file_generation/ttl=63d/output/`) and present both files to the user using `google:show_file`.
- State the length, how to use the HTML player (click or space to play with sound, arrow keys to step a frame), and one line noting any creative choice made on the user's behalf.
- When changes are asked for, move the previous cut to `P/v1/` (then `v2/`, ...) before re-rendering.
- When a request is a fresh take on an earlier premise, start the shot list from scratch instead of reusing the earlier version's shots.
